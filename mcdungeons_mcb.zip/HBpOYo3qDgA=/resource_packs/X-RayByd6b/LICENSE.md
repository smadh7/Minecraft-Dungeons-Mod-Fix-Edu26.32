[Terms of Use]
ATTENTION! 
BY POSESSING OR OPERATING ANY SOFTWARE* DISTRUIBUTED BY 'd6b' OR ANY OF HIS ASSOCIATES INDICATES THAT YOU HAVE READ, AND UNDERSTOOD THE TERMS OF USE, AND YOU ACCEPT THE TEARMS AND CONDITIONS STATED WITHIN THE 'TERMS OF USE'.

'd6b' or any of their associates shall not be held liable for any damage caused to property, Physical nor virtual. It is the responsibility of the software* operator to ensure the software* is being used for the intended purpose.
'd6b' or any of their associates shall not be held liable for loss of property, physical nor digital. The use of the provided software* may not be permitted in certain circumstances, and it is the responsibility of the software* operator to ensure that the possession and/or use of the software* provided is permitted. In such circumstance where the operator fails to ensure that the possession or use of the software* provided is permitted, any penalty issued directly caused by the use or possession of the software* is solely the liability of the operator.

THIS SOFTWARE* IS STRICTLY THE PROPERTY OF 'd6b' AND THEIR ASSOCIATES. ALL RIGHTS HAVE BEEN RESERVED TO RESTRICT, REMOVE AND DENY ACCESS AND/OR USE OF THE SOFTWARE*, AT WILL BY THOSE WHO HAVE PERMISSION TO DO SO.
THE COPYING, DISTROBUTING OR EDITING OF ANY OF THE SOFTWARE* PROVIDED WITHOUT EXPLICIT PERMISSION FROM 'D6B' OR ANY OF HIS ASSOCIATES WITH SUFFICHENT PRIVELAGES TO GRANT PERMISSION, IS STRICTLY PROHIBITED. #

[definitions]
software* = any firmware, software, resource packs, addons, files, programs or digital media
associates = those who are associated, related to, or well known by 'd6b' and are involved in distributing 'd6b's software*
‘d6b’ = those who identify by the alias “d6b”

[Contact]
https://discord.gg/2AeksvEDYm

Copyright ©️2020, d6b (https://d6b.dev/)